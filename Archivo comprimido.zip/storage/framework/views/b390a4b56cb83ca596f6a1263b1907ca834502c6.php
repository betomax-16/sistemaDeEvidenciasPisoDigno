 <?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/set1.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/contactanos.css')); ?>"> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<div class="paginas-internas">
    <main class="p-1">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h1 style="color:#c8ccd0;"><b>Formulario de contacto</b></h1> <?php echo Form::open(['route' => 'enviarContacto', 'method' => 'POST']); ?>


                    <span class="input input--hoshi">
                      <?php echo Form::text('nombre', old('nombre'), ['class' => 'input__field input__field--hoshi', 'autocomplete' => 'off']); ?>

        					    <label class="input__label <?php echo e($errors->has('nombre') ? ' error' : 'input__label--hoshi input__label--hoshi-color-1'); ?>" for="input-4">
        						    <span class="input__label-content <?php echo e(($errors->has('nombre') || old('nombre')) ? ' arriba' : 'input__label-content--hoshi'); ?>">Nombre</span>
                    </label>
                    </span>
                    <?php if($errors->has('nombre')): ?>
                    <span class="label-error">
                          <strong><?php echo e($errors->first('nombre')); ?></strong>
                      </span> <?php endif; ?>

                    <span class="input input--hoshi">
                    <?php echo Form::tel('telefono', old('telefono'), ['class' => 'input__field input__field--hoshi', 'autocomplete' => 'off']); ?>

      					    <label class="input__label <?php echo e($errors->has('telefono') ? ' error' : 'input__label--hoshi input__label--hoshi-color-2'); ?>" for="input-4">
      						    <span class="input__label-content <?php echo e(($errors->has('telefono') || old('telefono')) ? ' arriba' : 'input__label-content--hoshi'); ?>">Teléfono</span>
                    </label>
                    </span>
                    <?php if($errors->has('telefono')): ?>
                    <span class="label-error">
                          <strong><?php echo e($errors->first('telefono')); ?></strong>
                      </span> <?php endif; ?>

                    <span class="input input--hoshi">
                    <?php echo Form::email('email', old('email'), ['class' => 'input__field input__field--hoshi', 'autocomplete' => 'off']); ?>

      					    <label class="input__label <?php echo e($errors->has('email') ? ' error' : 'input__label--hoshi input__label--hoshi-color-3'); ?>" for="input-4">
      						    <span class="input__label-content <?php echo e(($errors->has('email') || old('email')) ? ' arriba' : 'input__label-content--hoshi'); ?>">Email</span>
                    </label>
                    </span>
                    <?php if($errors->has('email')): ?>
                    <span class="label-error">
                          <strong><?php echo e($errors->first('email')); ?></strong>
                      </span> <?php endif; ?>

                    <span class="input input--hoshi">
                    <?php echo Form::text('asunto', old('asunto'), ['class' => 'input__field input__field--hoshi', 'autocomplete' => 'off']); ?>

      					    <label class="input__label <?php echo e($errors->has('asunto') ? ' error' : 'input__label--hoshi input__label--hoshi-color-4'); ?>" for="input-4">
      						    <span class="input__label-content <?php echo e(($errors->has('asunto') || old('asunto')) ? ' arriba' : 'input__label-content--hoshi'); ?>">Asunto</span>
                    </label>
                    </span>
                    <?php if($errors->has('asunto')): ?>
                    <span class="label-error">
                          <strong><?php echo e($errors->first('asunto')); ?></strong>
                      </span> <?php endif; ?>

                    <span class="input input--hoshi">
                    <?php echo Form::textarea('mensaje', old('mensaje'), ['class' => 'input__field input__field--hoshi', 'autocomplete' => 'off', 'size' => '50x4']); ?>

      					    <label class="input__label <?php echo e($errors->has('mensaje') ? ' error' : 'input__label--hoshi input__label--hoshi-color-5'); ?>" for="input-4">
      						    <span class="input__label-content <?php echo e(($errors->has('mensaje') || old('mensaje')) ? ' arriba' : 'input__label-content--hoshi'); ?>">Mensaje</span>
                    </label>
                    </span>
                    <?php if($errors->has('mensaje')): ?>
                    <span class="label-error">
                          <strong><?php echo e($errors->first('mensaje')); ?></strong>
                      </span> <?php endif; ?>

                    <div class="col-md-10 offset-md-1">
                        <div class="buttons">
                            <?php echo Form::submit('Enviar', ['class' => 'btn blue']); ?> <?php echo Form::reset('Limpiar', ['class' => 'btn purple', 'id' => 'reset']); ?>

                        </div>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
                <div class="col-md-4">
                    <h3>Detalles de contacto</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque laborum commodi suscipit vitae eius perferendis consequuntur? Modi nihil aliquam, quas deserunt vitae atque suscipit ratione rerum eveniet. Qui, adipisci ad.</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque laborum commodi suscipit vitae eius perferendis consequuntur? Modi nihil aliquam, quas deserunt vitae atque suscipit ratione rerum eveniet. Qui, adipisci ad.</p>
                </div>
            </div>
        </div>
    </main>

</div>

<?php $__env->stopSection(); ?> <?php $__env->startSection('javascripts'); ?>

<script src="<?php echo e(asset('js/Contacto/Hoshi.js')); ?>"></script> <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>