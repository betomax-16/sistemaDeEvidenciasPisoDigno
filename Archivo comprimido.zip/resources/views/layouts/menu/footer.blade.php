<footer class="piedepagina p-y-1 " role="contentinfo">
    <div class="container">
        <p>2016 c GSUPPuebla Todos los derechos reservados</p>
        <ul class="redes-sociales">
            <li><a href="#"><i class="fa fa-facebook " aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter " aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-youtube " aria-hidden="true"></i></a></li>
        </ul>
    </div>
</footer>
<a class="ir-arriba" href="#"><i class="fa fa-arrow-circle-up " aria-hidden="true"></i></a>
