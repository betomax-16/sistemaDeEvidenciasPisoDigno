<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>Asunto: {{$data->asunto}}</h1>
    <h5>Telefono: {{$data->telefono}}</h5>
    <h5>Mensaje:</h5>
    <p>{{$data->mensaje}}</p>
  </body>
</html>
