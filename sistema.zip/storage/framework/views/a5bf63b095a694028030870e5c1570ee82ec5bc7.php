<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('jquery-ui/jquery-ui.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/imagenCerrar.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container espacioPagina">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><h1>Nueva Evidencia <?php echo e(Session::get('proyecto')); ?></h1></div>
                <div class="card-block">
                  <?php echo Form::open(['route' => 'evidencia.store', 'method' => 'POST', 'files' => true]); ?>

                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group<?php echo e($errors->has('idMunicipio') ? ' has-danger' : ''); ?>">
                        <?php echo Form::label('municipio', 'Municipio'); ?>

                        <?php echo Form::text('municipio', old('municipio'), ['placeholder' => 'Municipio...', 'id' => 'municipio', 'class' => 'form-control', 'autocomplete' => 'off']); ?>

                        <?php echo Form::hidden('idMunicipio', old('idMunicipio'), ['id' => 'idMunicipio']); ?>

                        <?php if($errors->has('idMunicipio') || $errors->has('municipio')): ?>
                            <span class="form-control-feedback">
                                <strong><?php echo e($errors->first('idMunicipio')); ?></strong>
                            </span>
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group<?php echo e($errors->has('idLocalidad') ? ' has-danger' : ''); ?>">
                        <?php echo Form::label('localidad', 'Localidad'); ?>

                        <?php echo Form::text('localidad', old('localidad'), ['placeholder' => 'Localidad...', 'id' => 'localidad', 'class' => 'form-control', 'autocomplete' => 'off', 'disabled']); ?>

                        <?php echo Form::hidden('idLocalidad', old('idLocalidad'), ['id' => 'idLocalidad']); ?>

                        <?php if($errors->has('idLocalidad') || $errors->has('localidad')): ?>
                            <span class="form-control-feedback">
                                <strong><?php echo e($errors->first('idLocalidad')); ?></strong>
                            </span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group<?php echo e($errors->has('familia') ? ' has-danger' : ''); ?>">
                        <?php echo Form::label('familia', 'Familia'); ?>

                        <?php echo Form::text('familia', old('familia'), ['placeholder' => 'Familia...', 'id' => 'familia', 'class' => 'form-control', 'autocomplete' => 'off']); ?>

                        <?php if($errors->has('familia')): ?>
                            <span class="form-control-feedback">
                                <strong><?php echo e($errors->first('familia')); ?></strong>
                            </span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-md-12">
                      <div id="acordion">
                        <h3>Foto 1</h3>
                        <div class="row">
                          <div class="col-md-12 <?php echo e($errors->has('foto1') ? ' has-danger' : ''); ?>">
                            <center><img class="img-thumbnail img-fluid box" src="<?php echo e(asset('imagenes/evidencias/foto.png')); ?>" alt="" id="img1"></center>
                            <?php echo Form::file('foto1', ['id' => 'foto1', 'style' => 'display:none']); ?>

                            <?php if($errors->has('foto1')): ?>
                                <span class="form-control-feedback">
                                    <strong><?php echo e($errors->first('foto1')); ?></strong>
                                </span>
                            <?php endif; ?>
                          </div>
                        </div>
                        <h3>Foto 2</h3>
                        <div class="row">
                          <div class="col-md-12 <?php echo e($errors->has('foto2') ? ' has-danger' : ''); ?>">
                            <center><img class="img-thumbnail img-fluid box" src="<?php echo e(asset('imagenes/evidencias/foto.png')); ?>" alt="" id="img2"></center>
                            <?php echo Form::file('foto2', ['id' => 'foto2', 'style' => 'display:none']); ?>

                            <?php if($errors->has('foto2')): ?>
                                <span class="form-control-feedback">
                                    <strong><?php echo e($errors->first('foto2')); ?></strong>
                                </span>
                            <?php endif; ?>
                          </div>
                        </div>
                        <h3>Foto 3</h3>
                        <div class="row">
                          <div class="col-md-12 <?php echo e($errors->has('foto3') ? ' has-danger' : ''); ?>">
                            <center><img class="img-thumbnail img-fluid box" src="<?php echo e(asset('imagenes/evidencias/foto.png')); ?>" alt="" id="img3"></center>
                            <?php echo Form::file('foto3', ['id' => 'foto3', 'style' => 'display:none']); ?>

                            <?php if($errors->has('foto3')): ?>
                                <span class="form-control-feedback">
                                    <strong><?php echo e($errors->first('foto3')); ?></strong>
                                </span>
                            <?php endif; ?>
                          </div>
                        </div>
                        <h3>Otras fotos</h3>
                        <div class="row <?php echo e($errors->get('fotoN.*') ? ' has-danger' : ''); ?>">
                          <div id="otros" class="row">
                            <div class="col-md-4">
                              <center>
                                <img class="img-thumbnail img-fluid box" src="<?php echo e(asset('imagenes/evidencias/foto.png')); ?>" alt="" id="imgN">
                              </center>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-md-12">
                              <label class="custom-file">
                                <?php echo Form::file('fotoN[]', ['class' => 'custom-file-input', 'id' => 'fotoN', 'multiple']); ?>

                                <span class="custom-file-control"></span>
                              </label>
                              <?php $__currentLoopData = $errors->get('fotoN.*'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <?php $__currentLoopData = $error; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                  <span class="form-control-feedback">
                                      <strong><?php echo e($value); ?></strong>
                                  </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-md-12">
                      <?php echo Form::submit('Guardar', ['class' => 'btn btn-success btn-lg', 'style' => 'width:100%', 'id' => 'btnGuardar']); ?>

                    </div>
                  </div>
                  <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('jquery-ui/jquery-ui.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/Evidencias/subirEvidencia.js')); ?>"></script>
<script type="text/javascript">
  var token = '<?php echo e(Session::token()); ?>';
  var imageDefault = '<?php echo e(asset("imagenes/evidencias/foto.png")); ?>'
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>