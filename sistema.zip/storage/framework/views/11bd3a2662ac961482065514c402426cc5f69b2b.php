<header>
    <div class="nav-bar">
        <a href="#" class="btn-menu">
            <button class="c-hamburger c-hamburger--htx" id="btn-menu">
                <span>toggle menu</span>
            </button> <span>
        <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('imagenes/aplicacion/Logo.svg')); ?>" alt="logo_del_sitio ">
        </a>
      </span>
        </a>
        <a href="#" class="btn orange donar">Donar</a>
    </div>
    <nav>
        <ul>
            <li class="active"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home" aria-hidden="true"></i>Inicio</a></li>
            <li><a href="<?php echo e(route('contacto')); ?>"><i class="fa fa-coffee" aria-hidden="true"></i>Contacto</a></li>
            <li class="sub-menu">
                <a href="#">
                    <i class="fa fa-commenting-o" aria-hidden="true"></i>Programas<i class="fa fa-angle-down cared" aria-hidden="true"></i>
                </a>
                <ul class="children">
                    <li><a href="<?php echo e(route('proyectosPorPrograma','VIVIENDA')); ?>">Vivienda</a></li>
                    <li><a href="<?php echo e(route('proyectosPorPrograma','SALUD')); ?>">Salud</a></li>
                    <li><a href="<?php echo e(route('proyectosPorPrograma','ALIMENTOS')); ?>">Alimentos</a></li>
                    <li><a href="<?php echo e(route('proyectosPorPrograma','EDUCACION')); ?>">Educación</a></li>
                    <li><a href="<?php echo e(route('proyectosPorPrograma','MEDIO_AMBIENTE')); ?>">Medio Ambiente</a></li>
                </ul>
            </li>
            <?php if(Auth::guest()): ?>
            <li><a href="<?php echo e(url('/login')); ?>"><i class="fa fa-heartbeat" aria-hidden="true"></i>Iniciar Sesión</a></li>
            <?php else: ?> <?php if(Auth::user()->role == 'ROLE_ADMIN'): ?>
            <li><a href="<?php echo e(route('usuario.index')); ?>"><i class="fa fa-coffee" aria-hidden="true"></i>Usuarios</a></li>
            <?php endif; ?>
            <li class="sub-menu">
                <a href="#">
                    <i class="fa fa-commenting-o" aria-hidden="true"></i><?php echo e(Auth::user()->nombre); ?><i class="fa fa-angle-down cared" aria-hidden="true"></i>
                </a>
                <ul class="children">
                    <li>
                        <a href="<?php echo e(url('/logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                      Cerrar Sesión
                  </a>
                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                </ul>
            </li>
            <?php endif; ?>
            <li class="donar"><a href=""><i class="fa fa-paw" aria-hidden="true"></i>Donar</a></li>
        </ul>
    </nav>
</header>
