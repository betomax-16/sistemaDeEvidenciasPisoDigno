<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container espacioPagina">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                  <h1>Nuevo Proyecto</h1>
                </div>
                <div class="panel-body">
                  <?php echo Form::open(['route' => 'proyecto.store', 'method' => 'POST']); ?>

                  <div class="form-group<?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
                    <?php echo Form::label('nombre', 'Proyecto'); ?>

                    <?php echo Form::text('nombre', old('nombre'), ['class' => 'form-control', 'placeholder' => 'Nombre de proyecto...', 'autocomplete' => 'off']); ?>

                    <?php echo Form::hidden('tipo', Session::get('programa')); ?>

                    <?php if($errors->has('nombre')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('nombre')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group">
                    <?php echo Form::submit('Guardar', ['class' => 'btn btn-success btn-lg']); ?>

                  </div>
                  <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>