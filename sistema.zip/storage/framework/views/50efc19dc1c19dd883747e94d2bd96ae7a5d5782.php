<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('jquery-ui/jquery-ui.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/fileInput/demo.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/fileInput/component.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container espacioPagina">
    <div class="row">
        <div class="col-md-12 ">
            <div class="card">
                <div class="card-header">
                  <div class="row">
                    <div class="col-xs-3 col-sm-2 col-md-1">
                      <a href="<?php echo e(URL::previous()); ?>" class="btn green btn-circle"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
                    </div>
                    <div class="col-xs-9 col-sm-10 col-md-11">
                      <h1>Editar Evidencia <?php echo e(Session::get('proyecto')); ?></h1>
                    </div>
                  </div>
                </div>
                <div class="card-block">
                  <?php echo Form::open(['route' => ['evidencia.update', $beneficiado->idHogar], 'method' => 'PUT', 'files' => true]); ?>

                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group<?php echo e($errors->has('idMunicipio') ? ' has-danger' : ''); ?>">
                        <?php echo Form::label('municipio', 'Municipio'); ?>

                        <?php echo Form::text('municipio', old('municipio') ? old('municipio') : $municipio->nombre, ['placeholder' => 'Municipio...', 'id' => 'municipio', 'class' => 'form-control', 'autocomplete' => 'off']); ?>

                        <?php echo Form::hidden('idMunicipio', old('idMunicipio') ? old('idMunicipio') : $municipio->idMunicipio, ['id' => 'idMunicipio']); ?>

                        <?php if($errors->has('idMunicipio') || $errors->has('municipio')): ?>
                            <span class="form-control-feedback">
                                <strong><?php echo e($errors->first('idMunicipio')); ?></strong>
                            </span>
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group<?php echo e($errors->has('idLocalidad') ? ' has-danger' : ''); ?>">
                        <?php echo Form::label('localidad', 'Localidad'); ?>

                        <?php echo Form::text('localidad', old('localidad') ? old('localidad') : $localidad->nombre, ['placeholder' => 'Localidad...', 'id' => 'localidad', 'class' => 'form-control', 'autocomplete' => 'off', 'disabled']); ?>

                        <?php echo Form::hidden('idLocalidad', old('idLocalidad') ? old('idLocalidad') : $localidad->idLocalidad, ['id' => 'idLocalidad']); ?>

                        <?php if($errors->has('idLocalidad') || $errors->has('localidad')): ?>
                            <span class="form-control-feedback">
                                <strong><?php echo e($errors->first('idLocalidad')); ?></strong>
                            </span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group<?php echo e($errors->has('familia') ? ' has-danger' : ''); ?>">
                        <?php echo Form::label('familia', 'Familia'); ?>

                        <?php echo Form::text('familia', old('familia') ? old('familia') : $beneficiado->familia, ['placeholder' => 'Familia...', 'id' => 'familia', 'class' => 'form-control', 'autocomplete' => 'off']); ?>

                        <?php if($errors->has('familia')): ?>
                            <span class="form-control-feedback">
                                <strong><?php echo e($errors->first('familia')); ?></strong>
                            </span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-md-12">
                      <div id="acordion">
                        <h3>Foto 1</h3>
                        <div class="row">
                          <div class="col-md-12 <?php echo e($errors->has('foto1') ? ' has-danger' : ''); ?>">
                            <?php ($existe = false); ?>
                            <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                              <?php if($foto->tipo == 'PISO_ORIGINAL'): ?>
                                <center><img class="img-thumbnail img-fluid box" src="<?php echo e(asset('imagenes/evidencias/').'/'.$foto->nombreArchivo); ?>" alt="" id="img1"></center>
                                <?php ($existe = true); ?>
                              <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <?php if(!$existe): ?>
                              <center><img class="img-thumbnail img-fluid box" src="<?php echo e(asset('imagenes/evidencias/foto.png')); ?>" alt="" id="img1"></center>
                            <?php endif; ?>
                            <?php echo Form::file('foto1', ['id' => 'foto1', 'style' => 'display:none']); ?>

                            <?php if($errors->has('foto1')): ?>
                                <span class="form-control-feedback">
                                    <strong><?php echo e($errors->first('foto1')); ?></strong>
                                </span>
                            <?php endif; ?>
                          </div>
                        </div>
                        <h3>Foto 2</h3>
                        <div class="row">
                          <div class="col-md-12 <?php echo e($errors->has('foto2') ? ' has-danger' : ''); ?>">
                            <?php ($existe = false); ?>
                            <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                              <?php if($foto->tipo == 'PISO_EN_PROCESO'): ?>
                                <center><img class="img-thumbnail img-fluid box" src="<?php echo e(asset('imagenes/evidencias/').'/'.$foto->nombreArchivo); ?>" alt="" id="img2"></center>
                                <?php ($existe = true); ?>
                              <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <?php if(!$existe): ?>
                              <center><img class="img-thumbnail img-fluid box" src="<?php echo e(asset('imagenes/evidencias/foto.png')); ?>" alt="" id="img2"></center>
                            <?php endif; ?>
                            <?php echo Form::file('foto2', ['id' => 'foto2', 'style' => 'display:none']); ?>

                            <?php if($errors->has('foto2')): ?>
                                <span class="form-control-feedback">
                                    <strong><?php echo e($errors->first('foto2')); ?></strong>
                                </span>
                            <?php endif; ?>
                          </div>
                        </div>
                        <h3>Foto 3</h3>
                        <div class="row">
                          <div class="col-md-12 <?php echo e($errors->has('foto3') ? ' has-danger' : ''); ?>">
                            <?php ($existe = false); ?>
                            <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                              <?php if($foto->tipo == 'PISO_TERMINADO'): ?>
                                <center><img class="img-thumbnail img-fluid box" src="<?php echo e(asset('imagenes/evidencias/').'/'.$foto->nombreArchivo); ?>" alt="" id="img3"></center>
                                <?php ($existe = true); ?>
                              <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <?php if(!$existe): ?>
                              <center><img class="img-thumbnail img-fluid box" src="<?php echo e(asset('imagenes/evidencias/foto.png')); ?>" alt="" id="img3"></center>
                            <?php endif; ?>
                            <?php echo Form::file('foto3', ['id' => 'foto3', 'style' => 'display:none']); ?>

                            <?php if($errors->has('foto3')): ?>
                                <span class="form-control-feedback">
                                    <strong><?php echo e($errors->first('foto3')); ?></strong>
                                </span>
                            <?php endif; ?>
                          </div>
                        </div>
                        <h3>Otras fotos</h3>
                        <div class="row <?php echo e($errors->get('fotoN.*') ? ' has-danger' : ''); ?>">
                          <div id="otros" class="row">
                            <?php ($existe = false); ?>
                            <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                              <?php if($foto->tipo == 'OTROS'): ?>
                              <div class="col-md-4">
                                <div class="image_wrapper">
                                  <center>
                                    <img class="img-thumbnail img-fluid box" src="<?php echo e(asset('imagenes/evidencias/').'/'.$foto->nombreArchivo); ?>" alt="" id="imgN">
                                    <img src="<?php echo e(asset('imagenes/aplicacion/cerrar24x24.png')); ?>" title="eliminar" class="remove">
                                  </center>
                                </div>
                              </div>
                                <?php ($existe = true); ?>
                              <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <?php if(!$existe): ?>
                            <div class="col-md-4">
                              <center><img class="img-thumbnail img-fluid box" src="<?php echo e(asset('imagenes/evidencias/foto.png')); ?>" alt="" id="imgN"></center>
                            </div>
                            <?php endif; ?>
                          </div>
                          <div class="row">
                            <div class="col-md-12">
                              <?php echo Form::file('fotoN[]', ['class' => 'inputfile inputfile-2', 'id' => 'fotoN', 'data-multiple-caption' => '{count} archivos seleccionados', 'style' => 'display:none', 'multiple']); ?>

                              <label for="file-2" id="inputN"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"/></svg> <span>Selecciona un archivo&hellip;</span></label>
                              <?php $__currentLoopData = $errors->get('fotoN.*'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <?php $__currentLoopData = $error; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                  <span class="form-control-feedback">
                                      <strong><?php echo e($value); ?></strong>
                                  </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-md-12">
                      <?php echo Form::submit('Guardar', ['class' => 'btn green-inverse btn-lg', 'style' => 'width:100%']); ?>

                    </div>
                  </div>
                  <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/inputFile/jquery-v1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/inputFile/jquery.custom-file-input.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('jquery-ui/jquery-ui.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/Evidencias/actualizarEvidencia.js')); ?>"></script>
<script type="text/javascript">
  var token = '<?php echo e(Session::token()); ?>';
  var imageDefault = '<?php echo e(asset("imagenes/evidencias/foto.png")); ?>'
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>