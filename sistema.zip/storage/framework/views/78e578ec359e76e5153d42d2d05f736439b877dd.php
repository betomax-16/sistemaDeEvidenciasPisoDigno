 <?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('jquery-ui/jquery-ui.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/evidencia.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>">
<?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<div class="container espacioPagina">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h1>Buscar Evidencias</h1>
                    <h4 style="display:inline"><span id='proyecto'><?php echo e($proyecto->nombre); ?></span>,  Entidad: <?php echo e($estado->nombre); ?></h4>
                </div>
                <?php if(!Auth::guest()): ?>
                <a href="<?php echo e(route('evidencia.create')); ?>" class="btn btn-lg btn-success" style="width:100%">Agregar Evidencia</a> <?php endif; ?>
                <div class="card-block">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-inline">
                                <div class="form-group">
                                    <button type="button" name="button" class="btn btn-success"><i class="fa fa-download" aria-hidden="true"></i> Excel</button>&nbsp;&nbsp;
                                    <?php echo Form::label('año', 'Año'); ?> <?php echo Form::number('año', Carbon\Carbon::now()->format('Y'), ['id' => 'año', 'class' => 'form-control']); ?>

                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form_group">
                                <?php echo Form::select('region', ['MUNICIPIO' => 'Municipio', 'LOCALIDAD' => 'Localidad'],'MUNICIPIO', ['class' => 'form-control', 'id' => 'region']); ?>

                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="input-group">
                                <?php echo Form::text('nombreLugar', $municipio ? $municipio->nombre : null, ['class' => 'form-control', 'id' => 'nombreLugar', 'placeholder' => 'Lugar...', 'autocomplete' => 'off']); ?>

                                <span class="input-group-btn">
                                  <button class="btn btn-secondary" type="button" id="btnBuscar"><i class="fa fa-search"></i></button>
                                </span>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="container" id="evidencias">
                      <?php if($beneficiados): ?> <?php echo $__env->make('layouts/templates/evidencias', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> <?php else: ?>
                      <h1 class="display-4 text-md-center">Sin evidencias</h1> <?php endif; ?>
                    </div>
                </div>
                <?php echo Form::open(['route' => ['evidencia.destroy', 'ID_HOGAR'], 'method' => 'DELETE', 'id' => 'form-delete']); ?> <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Modal title</h4>
      </div>
      <div class="modal-body">
        <center><img id="foto-modal" src="#" class="img-thumbnail img-responsive"></img></center>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?> <?php $__env->startSection('javascripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('jquery-ui/jquery-ui.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/Evidencias/buscarLocalidadEvidencia.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/Evidencias/eliminarEvidencia.js')); ?>"></script>
<script type="text/javascript">
    var token = '<?php echo e(Session::token()); ?>';
    var estado = '<?php echo e(Session::get("estado")); ?>';
    var proyecto = '<?php echo e(Session::get("proyecto")); ?>';
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>