<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container espacioPagina">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                  <div class="row">
                    <div class="col-xs-3 col-sm-2 col-md-1">
                      <a href="<?php echo e(URL::previous()); ?>" class="btn green btn-circle"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
                    </div>
                    <div class="col-xs-9 col-sm-10 col-md-11">
                      <h1>Nuevo Proyecto</h1>
                    </div>
                  </div>
                </div>
                <div class="card-block">
                  <?php echo Form::open(['route' => 'proyecto.store', 'method' => 'POST']); ?>

                  <div class="form-group<?php echo e($errors->has('nombre') ? ' has-danger' : ''); ?>">
                    <?php echo Form::label('nombre', 'Proyecto'); ?>

                    <?php echo Form::text('nombre', old('nombre'), ['class' => 'form-control', 'placeholder' => 'Nombre de proyecto...', 'autocomplete' => 'off']); ?>

                    <?php echo Form::hidden('tipo', Session::get('programa')); ?>

                    <?php if($errors->has('nombre')): ?>
                        <span class="form-control-feedback">
                            <strong><?php echo e($errors->first('nombre')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group">
                    <?php echo Form::submit('Guardar', ['class' => 'btn green-inverse btn-lg', 'style' => 'width:100%']); ?>

                  </div>
                  <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>