<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container espacioPagina">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                  <h1>Usuarios</h1>
                </div>
                <div class="panel-body">
                  <a class="btn btn-success btn-lg" href="<?php echo e(route('usuario.create')); ?>">Agregar Usuario</a>
                  <table class="table table-hover">
                    <thead>
                      <tr>
                        <th class="text-center">Nombre</th>
                        <th class="text-center">Email</th>
                        <th class="text-center">Rol</th>
                        <th class="text-center">Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr id="<?php echo e($usuario->idUsuario); ?>">
                          <td class="text-center"><?php echo e($usuario->nombreCompleto()); ?></td>
                          <td class="text-center"><?php echo e($usuario->email); ?></td>
                          <td class="text-center"><?php echo e($usuario->role); ?></td>
                          <td class="text-center">
                            <a class="btn btn-info" href="<?php echo e(route('usuario.edit', $usuario->idUsuario)); ?>">Editar</a>
                            <button type="button" name="button" class="btn btn-danger btn-delete">Eliminar</button>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </tbody>
                  </table>
                  <?php echo Form::open(['route' => ['usuario.destroy', 'ID_USUARIO'], 'method' => 'DELETE', 'id' => 'form-delete']); ?>

                  <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/bootbox.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/Usuarios/deleteUsuario.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>