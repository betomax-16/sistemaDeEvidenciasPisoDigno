<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container espacioPagina">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                  <h1>Usuarios</h1>
                </div>
                <div class="card-block">
                  <a class="btn btn-success btn-lg" href="<?php echo e(route('usuario.create')); ?>" style="width:100%">Agregar Usuario</a>
                  <table class="table table-hover">
                    <thead class="thead-inverse">
                      <tr>
                        <th class="text-md-center">Nombre</th>
                        <th class="text-md-center">Email</th>
                        <th class="text-md-center">Rol</th>
                        <th class="text-md-center">Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr id="<?php echo e($usuario->idUsuario); ?>">
                          <td class="text-md-center"><?php echo e($usuario->nombreCompleto()); ?></td>
                          <td class="text-md-center"><?php echo e($usuario->email); ?></td>
                          <?php if($usuario->role == 'ROLE_ADMIN'): ?>
                          <td class="text-md-center"><h5><span class="tag tag-pill tag-success">Administrador</span></h5></td>
                          <?php elseif($usuario->role == 'ROLE_PROVIDER'): ?>
                          <td class="text-md-center"><h5><span class="tag tag-pill tag-info">Proveedor de evidencias</span></h5></td>
                          <?php endif; ?>
                          <td class="text-md-center">
                            <div class="btn-group">
                              <a class="btn btn-info btn-secundary" href="<?php echo e(route('usuario.edit', $usuario->idUsuario)); ?>">Editar</a>
                              <button type="button" name="button" class="btn btn-danger btn-secundary btn-delete">Eliminar</button>
                            </div>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </tbody>
                  </table>
                  <?php echo Form::open(['route' => ['usuario.destroy', 'ID_USUARIO'], 'method' => 'DELETE', 'id' => 'form-delete']); ?>

                  <?php echo Form::close(); ?>

                  <?php echo e($usuarios->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/bootbox.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/Usuarios/deleteUsuario.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>