
      <?php if(count($beneficiados) > 0): ?>
        <?php $__currentLoopData = $beneficiados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beneficiado): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <?php ($fotos = $beneficiado->fotos); ?>
          <li>
            <?php if(!Auth::guest()): ?>
              <div class="remove" id="<?php echo e($beneficiado->idHogar); ?>"><img src="<?php echo e(asset('imagenes/aplicacion/cerrar24x24.png')); ?>" alt=""></div>
            <?php endif; ?>
            <?php if(!Auth::guest()): ?>
              <a href="<?php echo e(route('evidencia.edit', $beneficiado->idHogar)); ?>"><h3><?php echo e($beneficiado->familia); ?></h3></a>
            <?php else: ?>
              <h3><?php echo e($beneficiado->familia); ?></h3>
            <?php endif; ?>
            <div class="bb-bookblock">
              <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="bb-item"><a href="<?php echo e(asset('imagenes/evidencias').'/'.$foto->nombreArchivo); ?>" data-lightbox="<?php echo e($foto->idHogar); ?>" data-title="<?php echo e($foto->created_at); ?>"><img src="<?php echo e(asset('imagenes/evidencias').'/'.$foto->nombreArchivo); ?>" alt="<?php echo e($foto->tipo); ?>"/></a></div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </div>
            <nav>
              <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <?php if($foto->tipo == 'PISO_ORIGINAL'): ?>
                  <span class="bb-current"></span>
                <?php else: ?>
                  <span></span>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </nav>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <?php else: ?>
      <h1 class="display-4 text-md-center" style="overflow:auto;">No se encontraron evidencias.</h1>
    <?php endif; ?>
