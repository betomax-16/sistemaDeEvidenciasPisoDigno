<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('jquery-ui/jquery-ui.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/imagenes.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container espacioPagina">
    <div class="row">
        <div class="col-md-12">
            <?php if(!Auth::guest()): ?>
              <a href="<?php echo e(route('evidencia.create')); ?>" class="btn btn-lg btn-success" style="width:100%">Agregar Evidencia</a>
            <?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                  <h1>Buscar Evidencias</h1>
                  <h4 style="display:inline"><span id='proyecto'><?php echo e($proyecto->nombre); ?></span>,  Entidad: <?php echo e($estado->nombre); ?></h4>
                </div>
                <div class="panel-body">
                  <div class="row">
                    <div class="col-md-4">
                      <div class="form-inline">
                        <div class="form-group">
                          <?php echo Form::label('año', 'Año'); ?>

                          <?php echo Form::number('año', Carbon\Carbon::now()->format('Y'), ['id' => 'año', 'class' => 'form-control']); ?>

                        </div>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form_group">
                        <?php echo Form::select('region', ['MUNICIPIO' => 'Municipio', 'LOCALIDAD' => 'Localidad'],'MUNICIPIO', ['class' => 'form-control', 'id' => 'region']); ?>

                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="input-group">
                        <?php echo Form::text('nombreLugar', $municipio ? $municipio->nombre : null, ['class' => 'form-control', 'id' => 'nombreLugar', 'placeholder' => 'Lugar...', 'autocomplete' => 'off']); ?>

                        <span class="input-group-btn">
                          <button class="btn btn-default" type="button" id="btnBuscar"><span class="glyphicon glyphicon-search"></span></button>
                        </span>
                      </div>
                    </div>
                  </div>
                  <hr>
                  <div id="evidencias">
                    <?php if($beneficiados): ?>
                      <?php echo $__env->make('layouts/templates/templateEvidencia', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php else: ?>
                      <h2>Sin evidencias</h2>
                    <?php endif; ?>
                  </div>
                </div>
                <?php echo Form::open(['route' => ['evidencia.destroy', 'ID_HOGAR'], 'method' => 'DELETE', 'id' => 'form-delete']); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('jquery-ui/jquery-ui.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/Evidencias/buscarLocalidadEvidencia.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/Evidencias/eliminarEvidencia.js')); ?>"></script>
<script type="text/javascript">
  var token = '<?php echo e(Session::token()); ?>';
  var estado = '<?php echo e(Session::get("estado")); ?>';
  var proyecto = '<?php echo e(Session::get("proyecto")); ?>';
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>