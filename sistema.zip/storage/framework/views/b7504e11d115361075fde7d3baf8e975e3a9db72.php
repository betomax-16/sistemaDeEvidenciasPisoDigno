 <?php $__currentLoopData = $beneficiados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beneficiado): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>  
  <button class="fotos col-xs-12 col-md-3 text-xs-center " href="#FamiliaF" data-toggle="modal" data-target="#FamiliaF">
      <?php $__currentLoopData = $beneficiado->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="secundaria col-md-6">
            <?php if($foto->tipo == 'PISO_ORIGINAL'): ?>
            <img src="<?php echo e(asset('imagenes/evidencias').'/'.$foto->nombreArchivo); ?>" class="img-fluid  hidden-md-down" alt="">
            <?php endif; ?>
        </div>
        <div class="secundaria col-md-6">
            <?php if($foto->tipo == 'PISO_EN_PROCESO'): ?>
            <img src="<?php echo e(asset('imagenes/evidencias').'/'.$foto->nombreArchivo); ?>" class="img-fluid  hidden-md-down" alt="">
            <?php endif; ?>
        </div>
        <div class="principal " title='Agrega aquí el pie de foto'>
            <?php if($foto->tipo == 'PISO_TERMINADO'): ?>
            <img src="<?php echo e(asset('imagenes/evidencias').'/'.$foto->nombreArchivo); ?>" class="img-fluid " alt="">
            <?php endif; ?>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  </button>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
