<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container espacioPagina">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                  <h1>Agregar Usuario</h1>
                </div>
                <div class="panel-body">
                  <?php echo Form::open(['route' => 'usuario.store', 'method' => 'POST']); ?>

                  <div class="form-group<?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
                    <?php echo Form::label('nombre', 'Nombre'); ?>

                    <?php echo Form::text('nombre', old('nombre'), ['class' => 'form-control', 'placeholder' => 'Nombre...', 'autocomplete' => 'off']); ?>

                    <?php if($errors->has('nombre')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('nombre')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group<?php echo e($errors->has('apellidoPaterno') ? ' has-error' : ''); ?>">
                    <?php echo Form::label('apellidoPaterno', 'Apellido Paterno'); ?>

                    <?php echo Form::text('apellidoPaterno', old('apellidoPaterno'), ['class' => 'form-control', 'placeholder' => 'Apellido Paterno...', 'autocomplete' => 'off']); ?>

                    <?php if($errors->has('apellidoPaterno')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('apellidoPaterno')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group<?php echo e($errors->has('apellidoMaterno') ? ' has-error' : ''); ?>">
                    <?php echo Form::label('apellidoMaterno', 'Apellido Materno'); ?>

                    <?php echo Form::text('apellidoMaterno', old('apellidoMaterno'), ['class' => 'form-control', 'placeholder' => 'Apellido Materno...', 'autocomplete' => 'off']); ?>

                    <?php if($errors->has('apellidoMaterno')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('apellidoMaterno')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <?php echo Form::label('email', 'Email'); ?>

                    <?php echo Form::email('email', old('email'), ['class' => 'form-control', 'placeholder' => 'Email...', 'autocomplete' => 'off']); ?>

                    <?php if($errors->has('email')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <?php echo Form::label('password', 'Contraseña'); ?>

                    <?php echo Form::password('password', ['class' => 'form-control', 'placeholder' => 'Contraseña...', 'autocomplete' => 'off']); ?>

                    <?php if($errors->has('password')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group">
                    <?php echo Form::label('password', 'Confirmar contraseña'); ?>

                    <?php echo Form::password('password_confirmation', ['class' => 'form-control', 'placeholder' => 'Contraseña...', 'autocomplete' => 'off']); ?>

                  </div>
                  <div class="form-group">
                    <?php echo Form::label('role', 'Rol'); ?>

                    <?php echo Form::select('role', ['ROLE_PROVIDER' => 'Proveedor de Evidencias', 'ROLE_ADMIN' => 'Administrador'], 'ROLE_PROVIDER', ['class' => 'form-control']); ?>

                  </div>
                  <div class="form-group">
                    <?php echo Form::submit('Guardar', ['class' => 'btn btn-success btn-lg']); ?>

                  </div>
                  <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>