<div class="modal fade" id="PisoD" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Piso Digno</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-8" id="modal-texto">
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio, ducimus. Eum, voluptas libero esse possimus voluptatum quod facilis a. Modi cumque amet aperiam dignissimos pariatur in ipsa cupiditate quisquam, eum! Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni illum placeat at, rerum ex, aperiam ut quaerat perspiciatis nulla ipsa animi quia consectetur omnis autem in inventore voluptatibus ea soluta. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Labore doloribus, impedit, obcaecati quasi similique ipsum expedita hic nesciunt delectus, modi, autem sequi nihil repudiandae consequatur! Impedit, dignissimos quo architecto earum!
                    </div>
                    <div class="col-md-4 text-xs-center">
                        <img id="modal-img" src="<?php echo e(asset('imagenes/aplicacion/Bivienda.svg')); ?>" alt="" class="img-fluid  " width="200">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
              <a id="ir" href="#" class="btn blue-inverse" style="width:100%">Ir</a>
            </div>
        </div>
    </div>
</div>
