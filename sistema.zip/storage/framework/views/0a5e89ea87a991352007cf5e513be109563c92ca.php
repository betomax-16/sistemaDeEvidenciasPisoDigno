 <?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/contactanos.css')); ?>">
<?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="paginas-internas">
    <main class="p-1">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                  <div class="form-container">
                    <div class="form-header">
                      <h1>Formulario de contacto</h1>
                    </div>
                    <div class="form-body">
                      <?php echo Form::open(['route' => 'enviarContacto', 'method' => 'POST']); ?>

                      <div class="form-group <?php echo e($errors->has('nombre') ? 'has-danger' : ''); ?>">
                        <label>Nombre</label>
                        <?php ($error = $errors->has('nombre') ? 'form-control-danger' : ''); ?>
                        <?php echo Form::text('nombre', old('nombre'), ['class' => 'form-control '.$error, 'autocomplete' => 'off']); ?>

                        <?php if($errors->has('nombre')): ?>
                          <div class="message-error"><?php echo e($errors->first('nombre')); ?></div>
                        <?php endif; ?>
                      </div>
                      <div class="form-group <?php echo e($errors->has('telefono') ? 'has-danger' : ''); ?>">
                          <label>Teléfono</label>
                          <?php ($error = $errors->has('telefono') ? 'form-control-danger' : ''); ?>
                          <?php echo Form::tel('telefono', old('telefono'), ['class' => 'form-control '.$error, 'autocomplete' => 'off']); ?>

                          <?php if($errors->has('telefono')): ?>
                            <div class="message-error"><?php echo e($errors->first('telefono')); ?></div>
                          <?php endif; ?>
                      </div>
                      <div class="form-group <?php echo e($errors->has('email') ? 'has-danger' : ''); ?>">
                        <label>Email</label>
                        <?php ($error = $errors->has('email') ? 'form-control-danger' : ''); ?>
                        <?php echo Form::email('email', old('email'), ['class' => 'form-control '.$error, 'autocomplete' => 'off']); ?>

                        <?php if($errors->has('email')): ?>
                          <div class="message-error"><?php echo e($errors->first('email')); ?></div>
                        <?php endif; ?>
                      </div>
                      <div class="form-group <?php echo e($errors->has('asunto') ? 'has-danger' : ''); ?>">
                        <label>Asunto</label>
                        <?php ($error = $errors->has('asunto') ? 'form-control-danger' : ''); ?>
                        <?php echo Form::text('asunto', old('asunto'), ['class' => 'form-control '.$error, 'autocomplete' => 'off']); ?>

                        <?php if($errors->has('asunto')): ?>
                          <div class="message-error"><?php echo e($errors->first('asunto')); ?></div>
                        <?php endif; ?>
                      </div>
                      <div class="form-group <?php echo e($errors->has('mensaje') ? 'has-danger' : ''); ?>">
                        <label>Mensaje</label>
                        <?php echo Form::textarea('mensaje', old('mensaje'), ['class' => 'form-control ', 'autocomplete' => 'off', 'size' => '50x4']); ?>

                        <?php if($errors->has('mensaje')): ?>
                          <div class="message-error"><?php echo e($errors->first('mensaje')); ?></div>
                        <?php endif; ?>
                      </div>
                      <div class="form-group" style="margin-top:25px;">
                        <center>
                          <?php echo Form::submit('Enviar', ['class' => 'btn green-inverse']); ?>

                          <?php echo Form::reset('Limpiar', ['class' => 'btn blue-inverse', 'id' => 'reset']); ?>

                        </center>
                      </div>
                      <?php echo Form::close(); ?>

                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                    <h3>Detalles de contacto</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque laborum commodi suscipit vitae eius perferendis consequuntur? Modi nihil aliquam, quas deserunt vitae atque suscipit ratione rerum eveniet. Qui, adipisci ad.</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque laborum commodi suscipit vitae eius perferendis consequuntur? Modi nihil aliquam, quas deserunt vitae atque suscipit ratione rerum eveniet. Qui, adipisci ad.</p>
                </div>
            </div>
        </div>
    </main>

</div>

<?php $__env->stopSection(); ?> <?php $__env->startSection('javascripts'); ?>
<script type="text/javascript">
var wf_pbb_object = [
{bc:"rgb(255, 255, 255)"},
{img:"http://web-features.net/patterns/14.png", mm:false, ms:true, mms:1, mss:5, mmd:1, mso:"d", msd:1, im:"pattern", pr:"both", mma:"both", ofs:{x:0, y:0}, zi:1, sr:false, sb:false, isr:true, isb:false}
];
</script>
<script type="text/javascript" src="http://web-features.net/api/wf.pbb.api.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>