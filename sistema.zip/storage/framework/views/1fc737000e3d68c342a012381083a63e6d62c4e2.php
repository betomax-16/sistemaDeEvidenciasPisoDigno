<section class="Top">
    <header class="encavezado navbar-fixed-top" role="banner">
        <div class="container">
            <a href="<?php echo e(url('/')); ?>" class="logo">
                <img src="<?php echo e(asset('images/Logo.svg')); ?>" alt="logo_del_sitio ">
            </a>
            <button class="c-hamburger c-hamburger--htx boton-menu hidden-md-up" data-toggle="collapse" data-target="#menu-principal" aria-expanded="false">
                <span>toggle menu</span>
            </button>


            <nav class="collapse" id="menu-principal">
                <ul>
                    <li><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                    <li><a href="<?php echo e(url('/').'#nosotros'); ?>">Nosotros</a></li>
                    <li><a href="<?php echo e(url('/').'#mision'); ?>">Mision y Vision</a></li>
                    <li><a href="#">Contacto</a></li>
                    <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                          Programas
                      </a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="<?php echo e(route('proyectosPorPrograma','VIVIENDA')); ?>">Vivienda</a></li>
                        <li><a href="<?php echo e(route('proyectosPorPrograma','SALUD')); ?>">Salud</a></li>
                        <li><a href="<?php echo e(route('proyectosPorPrograma','ALIMENTOS')); ?>">Alimentos</a></li>
                        <li><a href="<?php echo e(route('proyectosPorPrograma','EDUCACION')); ?>">Educacion</a></li>
                        <li><a href="<?php echo e(route('proyectosPorPrograma','MEDIO_AMBIENTE')); ?>">Medio Ambiente</a></li>
                      </ul>
                    </li>
                    <?php if(Auth::guest()): ?>
                        <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                    <?php else: ?>
                      <?php if(Auth::user()->role == 'ROLE_ADMIN'): ?>
                        <li><a href="<?php echo e(route('usuario.index')); ?>">Usuarios</a></li>
                      <?php endif; ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                <?php echo e(Auth::user()->nombre); ?> <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu" role="menu">
                                <li>
                                    <a href="<?php echo e(url('/logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                        Logout
                                    </a>
                                    <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>
</section>
