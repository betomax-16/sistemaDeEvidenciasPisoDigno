<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container espacioPagina">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                  <div class="row">
                    <div class="col-xs-3 col-sm-2 col-md-1">
                      <a href="<?php echo e(URL::previous()); ?>" class="btn green btn-circle"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
                    </div>
                    <div class="col-xs-9 col-sm-10 col-md-11">
                      <h1>Editar Usuario</h1>
                    </div>
                  </div>
                </div>
                <div class="card-block">
                  <?php echo Form::model($usuario, ['route' => ['usuario.update', $usuario->idUsuario], 'method' => 'PUT']); ?>

                  <div class="form-group<?php echo e($errors->has('nombre') ? ' has-danger' : ''); ?>">
                    <?php echo Form::label('nombre', 'Nombre'); ?>

                    <?php echo Form::text('nombre', old('nombre'), ['class' => 'form-control', 'placeholder' => 'Nombre...', 'autocomplete' => 'off']); ?>

                    <?php if($errors->has('nombre')): ?>
                        <span class="form-control-feedback">
                            <strong><?php echo e($errors->first('nombre')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group<?php echo e($errors->has('apellidoPaterno') ? ' has-danger' : ''); ?>">
                    <?php echo Form::label('apellidoPaterno', 'Apellido Paterno'); ?>

                    <?php echo Form::text('apellidoPaterno', old('apellidoPaterno'), ['class' => 'form-control', 'placeholder' => 'Apellido Paterno...', 'autocomplete' => 'off']); ?>

                    <?php if($errors->has('apellidoPaterno')): ?>
                        <span class="form-control-feedback">
                            <strong><?php echo e($errors->first('apellidoPaterno')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group<?php echo e($errors->has('apellidoMaterno') ? ' has-danger' : ''); ?>">
                    <?php echo Form::label('apellidoMaterno', 'Apellido Materno'); ?>

                    <?php echo Form::text('apellidoMaterno', old('apellidoMaterno'), ['class' => 'form-control', 'placeholder' => 'Apellido Materno...', 'autocomplete' => 'off']); ?>

                    <?php if($errors->has('apellidoMaterno')): ?>
                        <span class="form-control-feedback">
                            <strong><?php echo e($errors->first('apellidoMaterno')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                    <?php echo Form::label('email', 'Email'); ?>

                    <?php echo Form::email('email', old('email'), ['class' => 'form-control', 'placeholder' => 'Email...', 'autocomplete' => 'off']); ?>

                    <?php if($errors->has('email')): ?>
                        <span class="form-control-feedback">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                    <?php echo Form::label('password', 'Contraseña'); ?>

                    <?php echo Form::password('password', ['class' => 'form-control', 'placeholder' => 'Contraseña...', 'autocomplete' => 'off']); ?>

                    <?php if($errors->has('password')): ?>
                        <span class="form-control-feedback">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group">
                    <?php echo Form::label('password', 'Confirmar contraseña'); ?>

                    <?php echo Form::password('password_confirmation', ['class' => 'form-control', 'placeholder' => 'Contraseña...', 'autocomplete' => 'off']); ?>

                  </div>
                  <div class="form-group">
                    <?php echo Form::label('role', 'Rol'); ?>

                    <?php echo Form::select('role', ['ROLE_PROVIDER' => 'Proveedor de Evidencias', 'ROLE_ADMIN' => 'Administrador'], null, ['class' => 'form-control']); ?>

                  </div>
                  <hr>
                  <div class="form-group">
                    <?php echo Form::submit('Guardar', ['class' => 'btn green-inverse btn-lg', 'style' => 'width:100%']); ?>

                  </div>
                  <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>