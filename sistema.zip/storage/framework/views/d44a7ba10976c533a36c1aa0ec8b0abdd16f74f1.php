<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container espacioPagina">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                  <h1>Proyectos de tipo: <?php echo e($programa); ?></h1>
                  <h4 style="display:inline"> Entidad: <?php echo e($estado->nombre); ?></h4>
                </div>
                <div class="card-block">
                  <?php if(!Auth::guest() and Auth::user()->role == 'ROLE_ADMIN'): ?>
                    <a class="btn btn-success btn-lg" href="<?php echo e(route('proyecto.create')); ?>" style="width:100%">Nuevo Proyecto</a>
                  <?php endif; ?>
                  <?php if(count($proyectos) == 0 and !Auth::guest() and Auth::user()->role == 'ROLE_PROVIDER'): ?>
                    <h1 class="display-4 text-md-center">No participa en ningún proyecto.</h1>
                  <?php elseif(count($proyectos) == 0): ?>
                    <h1 class="display-4 text-md-center">Sin proyectos activos</h1>
                  <?php endif; ?>
                  <?php if(count($proyectos) > 0): ?>
                    <table class="table table-hover">
                      <thead>
                        <tr class="thead-inverse">
                          <th class="text-md-center">Proyecto</th>
                          <th class="text-md-center">Fecha de inicio</th>
                          <th class="text-md-center">Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                          <tr id="<?php echo e($proyecto->nombre); ?>">
                            <td class="text-md-center"><b><?php echo e($proyecto->nombre); ?></b></td>
                            <td class="text-md-center"><?php echo e(Carbon\Carbon::createFromFormat('Y-m-d H:i:s',$proyecto->created_at)->format('Y-m-d')); ?></td>
                            <td class="text-md-center">
                              <div class="btn-group">
                                <a class="btn btn-success btn-secundary" href="<?php echo e(route('evidencia.evidencias', [$proyecto->nombre, $estado->idEstado])); ?>">Ver evidencias</a>
                                <?php if(!Auth::guest() and Auth::user()->role == 'ROLE_ADMIN'): ?>
                                  <a class="btn btn-info btn-secundary" href="<?php echo e(route('proyecto.edit', [$proyecto->nombre])); ?>">Editar</a>
                                  <button type="button" name="button" class="btn btn-danger btn-secundary btn-delete">Eliminar</button>
                                  <a class="btn btn-warning btn-secundary" href="<?php echo e(route('participante.index', [$proyecto->nombre, $estado->idEstado])); ?>">Participantes</a>
                                <?php endif; ?>
                              </div>
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                      </tbody>
                    </table>
                  <?php endif; ?>
                  <?php echo Form::open(['route' => ['proyecto.destroy', 'ID_PROYECTO'], 'method' => 'DELETE', 'id' => 'form-delete']); ?>

                  <?php echo Form::close(); ?>

                  <?php echo $proyectos->render(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/Proyectos/deleteProyecto.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>