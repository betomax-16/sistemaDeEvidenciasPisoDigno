<div class="row">
  <?php $__currentLoopData = $beneficiados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beneficiado): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
  <div class="col-md-4" id="evidencia<?php echo e($beneficiado->idHogar); ?>">
    <a href="<?php echo e(route((!Auth::guest()) ? 'evidencia.edit' : 'evidencia.ver', $beneficiado->idHogar)); ?>">
      <div class="panel panel-primary">
          <div class="panel-heading">
            Familia: <b><span><?php echo e($beneficiado->familia); ?></span></b>
            <?php if(!Auth::guest()): ?>
              <button type="button" name="button" class="btn btn-danger" id="<?php echo e($beneficiado->idHogar); ?>" style="float:right; margin-top:-7px; margin-right:-11px;">X</button>
            <?php endif; ?>
          </div>
          <div class="panel-body">
            <?php ($fotos = count($beneficiado->fotos)); ?>
            <?php if($fotos == 1): ?>
              <div class="row">
                  <div class="col-md-6">
                      <center><img src="<?php echo e(asset('imagenes/evidencias').'/foto.png'); ?>" class="img-thumbnail img-responsive box"></img></center>
                  </div>
                  <div class="col-md-6">
                      <center><img src="<?php echo e(asset('imagenes/evidencias').'/foto.png'); ?>" class="img-thumbnail img-responsive box"></img></center>
                  </div>
              </div></br>
              <div class="row">
                  <div class="col-md-12">
                      <center><img src="<?php echo e(asset('imagenes/evidencias').'/'.$beneficiado->fotos[0]->nombreArchivo); ?>" class="img-thumbnail img-responsive bigbox"></img></center>
                  </div>
              </div>
            <?php elseif($fotos == 2): ?>
              <div class="row">
                  <div class="col-md-6">
                      <center><img src="<?php echo e(asset('imagenes/evidencias').'/'.$beneficiado->fotos[0]->nombreArchivo); ?>" class="img-thumbnail img-responsive box"></img></center>
                  </div>
                  <div class="col-md-6">
                      <center><img src="<?php echo e(asset('imagenes/evidencias').'/'.$beneficiado->fotos[1]->nombreArchivo); ?>" class="img-thumbnail img-responsive box"></img></center>
                  </div>
              </div></br>
              <div class="row">
                  <div class="col-md-12">
                      <center><img src="<?php echo e(asset('imagenes/evidencias').'/foto.png'); ?>" class="img-thumbnail img-responsive bigbox"></img></center>
                  </div>
              </div>
            <?php elseif($fotos >= 3): ?>
              <div class="row">
                  <div class="col-md-6">
                      <center><img src="<?php echo e(asset('imagenes/evidencias').'/'.$beneficiado->fotos[0]->nombreArchivo); ?>" class="img-thumbnail img-responsive box"></img></center>
                  </div>
                  <div class="col-md-6">
                      <center><img src="<?php echo e(asset('imagenes/evidencias').'/'.$beneficiado->fotos[1]->nombreArchivo); ?>" class="img-thumbnail img-responsive box"></img></center>
                  </div>
              </div></br>
              <div class="row">
                  <div class="col-md-12">
                      <center><img src="<?php echo e(asset('imagenes/evidencias').'/'.$beneficiado->fotos[2]->nombreArchivo); ?>" class="img-thumbnail img-responsive bigbox"></img></center>
                  </div>
              </div>
            <?php endif; ?>
          </div>
      </div>
    </a>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<div class="row">
  <div class="col-md-12">
    <?php echo e($beneficiados->links()); ?>

  </div>
</div>
