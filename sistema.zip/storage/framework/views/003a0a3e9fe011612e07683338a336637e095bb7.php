 <?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>"> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<div class="login-form container">
    <div class="row">
        <h1>Iniciar Sesión</h1>
        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email..." required autofocus autocomplete="off">
                <i class="fa fa-user"></i>
            </div>
            <div class="form-group log-status">
                <input id="password" type="password" class="form-control" name="password" placeholder="Contraseña..." required>
                <i class="fa fa-lock"></i>
            </div>
            <?php if($errors->has('email') or $errors->has('password')): ?>
            <span class="alert"><strong>Credenciales invalidas</strong></span> <?php endif; ?>
            <div class="form-group">
                <label style="color:darkgrey;">
                    <input type="checkbox" name="remember"> Recordarme
                </label>
            </div>
            <!--<a class="link" href="#">Lost your password?</a>-->
            <button type="submit" class="log-btn">Ingresar</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>