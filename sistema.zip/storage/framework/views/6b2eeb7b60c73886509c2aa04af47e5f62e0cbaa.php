<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container espacioPagina">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                  <h1>Contacto</h1>
                </div>
                <div class="card-block">
                  <?php echo Form::open(['route' => 'enviarContacto', 'method' => 'POST']); ?>

                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group<?php echo e($errors->has('nombre') ? ' has-danger' : ''); ?>">
                        <?php echo Form::text('nombre', old('nombre'), ['class' => 'form-control', 'placeholder' => 'Nombre...', 'autocomplete' => 'off']); ?>

                        <?php if($errors->has('nombre')): ?>
                            <span class="form-control-feedback">
                                <strong><?php echo e($errors->first('nombre')); ?></strong>
                            </span>
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                        <?php echo Form::email('email', old('email'), ['class' => 'form-control', 'placeholder' => 'Email...', 'autocomplete' => 'off']); ?>

                        <?php if($errors->has('email')): ?>
                            <span class="form-control-feedback">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group<?php echo e($errors->has('mensaje') ? ' has-danger' : ''); ?>">
                        <?php echo Form::textarea('mensaje', old('mensaje'), ['class' => 'form-control', 'placeholder' => 'Mensaje...']); ?>

                        <?php if($errors->has('mensaje')): ?>
                            <span class="form-control-feedback">
                                <strong><?php echo e($errors->first('mensaje')); ?></strong>
                            </span>
                        <?php endif; ?>
                      </div>
                      <hr>
                      <div class="form-group">
                        <?php echo Form::submit('Enviar', ['class' => 'btn btn-success btn-lg', 'style' => 'width:100%']); ?>

                      </div>
                    </div>
                  </div>
                  <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>