<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('jquery-ui/jquery-ui.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>">
<style media="screen">
.box{
  height: 250px;
  overflow: hidden;
}
.box img{
	height: 100%;
	width: 100%;
	object-fit:cover;
	-o-object-fit:cover;
}

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container espacioPagina">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                  <h1>Familia: <?php echo e($beneficiado->familia); ?></h1>
                  <h5>Proyecto: <?php echo e(Session::get('proyecto')); ?></h5>
                  <h6 class="text-md-right">Municipio: <?php echo e($municipio->nombre); ?> / Localidad: <?php echo e($localidad->nombre); ?> / Fecha: <?php echo e(Carbon\Carbon::createFromFormat('Y-m-d H:i:s',$beneficiado->created_at)->format('Y-m-d')); ?></h6>
                </div>
                <div class="card-block">
                  <div id="fotos" class="row">
                    <?php ($fotos = $beneficiado->fotos); ?>
                    <?php ($col = 0); ?>
                    <?php if(count($fotos) == 1): ?>
                      <?php ($col = 12); ?>
                    <?php elseif(count($fotos) == 2): ?>
                      <?php ($col = 6); ?>
                    <?php elseif(count($fotos) > 2): ?>
                      <?php ($col = 4); ?>
                    <?php endif; ?>
                    <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                      <div class="col-md-<?php echo e($col); ?>">
                          <center><img id="<?php echo e($foto->idFoto); ?>" alt="<?php echo e($foto->tipo); ?>" src="<?php echo e(asset('imagenes/evidencias').'/'.$foto->nombreArchivo); ?>" class="img-thumbnail img-fluid box" data-toggle="modal" data-target="#myModal"></img></center>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                  </div>
              </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Modal title</h4>
      </div>
      <div class="modal-body">
        <img id="foto-modal" src="#" class="img-thumbnail img-responsive"></img>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('jquery-ui/jquery-ui.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/Evidencias/verFoto.js')); ?>"></script>
<script type="text/javascript">
  var token = '<?php echo e(Session::token()); ?>';
  var imageDefault = '<?php echo e(asset("imagenes/evidencias/foto.png")); ?>'
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>