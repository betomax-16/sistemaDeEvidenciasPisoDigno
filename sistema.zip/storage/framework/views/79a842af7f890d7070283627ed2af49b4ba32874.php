<div class="row">
  <?php $__currentLoopData = $beneficiados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beneficiado): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
  <?php ($fotos = $beneficiado->fotos); ?>
  <div class="col-md-4" id="evidencia<?php echo e($beneficiado->idHogar); ?>">
    <div class="container-image image_wrapper">
      <?php if(!Auth::guest()): ?>
      <div class="remove" id="<?php echo e($beneficiado->idHogar); ?>"><img src="<?php echo e(asset('imagenes/aplicacion/cerrar24x24.png')); ?>" alt=""></div>
      <?php endif; ?>
      <div class="secundario">
        <?php if(count($fotos)>=1): ?>
          <div class="item"><img src="<?php echo e(asset('imagenes/evidencias').'/'.$fotos[0]->nombreArchivo); ?>" alt="<?php echo e($fotos[0]->tipo); ?>" data-toggle="modal" data-target="#myModal"></div>
        <?php else: ?>
          <div class="item"><center><img src="<?php echo e(asset('imagenes/evidencias/foto.png')); ?>" alt="Sin definir"></center></div>
        <?php endif; ?>
        <?php if(count($fotos)>=2): ?>
          <div class="item"><img src="<?php echo e(asset('imagenes/evidencias').'/'.$fotos[1]->nombreArchivo); ?>" alt="<?php echo e($fotos[1]->tipo); ?>" data-toggle="modal" data-target="#myModal"></div>
        <?php else: ?>
          <div class="item"><center><img src="<?php echo e(asset('imagenes/evidencias/foto.png')); ?>" alt="Sin definir"></center></div>
        <?php endif; ?>
      </div>
      <div class="primario">
        <?php if(count($fotos)>=3): ?>
          <div class="item"><center><img src="<?php echo e(asset('imagenes/evidencias').'/'.$fotos[2]->nombreArchivo); ?>" alt="<?php echo e($fotos[2]->tipo); ?>" data-toggle="modal" data-target="#myModal"></center></div>
        <?php else: ?>
          <div class="item"><center><img src="<?php echo e(asset('imagenes/evidencias/foto.png')); ?>" alt="Sin definir"></center></div>
        <?php endif; ?>
      </div>
      <a href="<?php echo e(route((!Auth::guest()) ? 'evidencia.edit' : 'evidencia.ver', $beneficiado->idHogar)); ?>">
        <div class="titulo">
          <div class="item"><?php echo e($beneficiado->familia); ?></div>
        </div>
      </a>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<div class="row">
  <div class="col-md-12">
    <?php echo e($beneficiados->links()); ?>

  </div>
</div>
