<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading"><h1>Proyectos</h1></div>
                <div class="panel-body">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th class="text-center">Proyecto</th>
                          <th class="text-center">Fecha de creacion</th>
                          <th class="text-center">Estado</th>
                          <th class="text-center">Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                          <tr>
                            <td class="text-center"><?php echo e($proyecto->nombre); ?></td>
                            <td class="text-center"><?php echo e($proyecto->created_at); ?></td>
                            <?php ($aux = array()); ?>
                            <?php $__currentLoopData = $proyecto->estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                              <?php ($aux[$estado->idEstado] = $estado->nombre); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <td class="text-center"><?php echo Form::select('estado', $aux, null, ['class' => 'form-control']); ?></td>
                            <td>
                              <a href="<?php echo e(route('proyecto.show', $proyecto->nombre)); ?>" class="btn btn-success" style="width:100%">Abrir</a>
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                      </tbody>
                    </table>
                    <?php echo $proyectos->render(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>